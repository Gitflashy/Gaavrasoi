Gaavrasoi Website - README
--------------------------
Files included:
- index.html        : Main website file. Upload this to InfinityFree htdocs.
- images/           : Put your images here (logo.png, hero-snacks.jpg, puruliya.jpg, laddu.jpg, favicon.png).

How to use:
1. Extract this ZIP on your laptop.
2. Edit index.html if you want to change phone/email/price/text.
3. Upload all files and the 'images' folder into your InfinityFree account's `htdocs` folder.
   - In InfinityFree File Manager, make sure index.html is directly inside htdocs (not in a subfolder) for the site root.
4. Replace placeholder images by adding real images in the images/ folder with the same filenames.
5. Test the site on your domain: https://yourdomain.infinityfreeapp.com
6. If contact form (mailto) does not work, consider using Formspree or a PHP mail handler.

Need changes? Reply here with:
- Your phone number (for WhatsApp links)
- Your email
- Any product price changes
- Your images (I can help replace them into the ZIP)
